<?php

//------------Note You must use paid cpanel hosting ---------------

$domainName = "website.com"; // Enter Domain Name Here
$webmail ="info@website.com"; // Enter Webmail Email
$webmailPass = "123456";  //Enter Webmail Password
$recieverMail ="test@gmail.com"; // Your reciever email address


//----------------------------------

?>
